# BRFNTify Next
### Beta Version

By Tempus  
"Next" version by RoadrunnerWMC

## Requirements

Requires Python 3, PyQt5 and TPLLib

## Credits
 * Tempus, for making the first version of this
 * Treeki, for building it
 * RoadrunnerWMC, for making it better
 * RVLution.net, for being an awesome Wii hacking site
 * Everybody else who deserves credit
 * FlatIcons.net, for the icon set

## TODO:
 * TPL
   - Test all decoders because some maybe don't work with Py3
 * Encode all formats
 * Import
 * New Font Generator
   - Fix it so it actually works right
   - TPL Selector
   - Encoding Selector
 * More icons
 * First time showing the Text Preview dock causes the scene to go black?
 * New readme