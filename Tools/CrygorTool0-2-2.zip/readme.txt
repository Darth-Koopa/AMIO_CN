CrygorTool 0.2.1 by scupizzaboy

CrygorTool is a saved microgame editor for WarioWare DIY.

Homepage:
http://scupizzaboy.blogspot.com

Note: I may use the term "microgame" to also refer to records and comic.

Version History:
0.2.2 April 10 2010
- Fixed an imported microgame having the chance to overwrite saved progress in the Job Center.
0.2.1 April 10 2010
- Fixed a bug where an imported microgame could overwrite your Game MakerMatic data!
- Fixed a bug created in 0.2 that would save a file to a blank name if you canceled the save.
0.2 April 10 2010
- Added very basic support for records/comics (it's sort of hacked in, will improve eventually).
- Locked games will still show a preview.
- REALLY fixed the bug where importing microgames would save over the first slot or copy a game multiple times.
- Fixed a bug where opening a .sav with a .sav already opened broke the microgame list.
- Fixed a bog where the file extension was not saved if you did not type it in the file name.
0.1.1 April 7 2010
- Reduced memory use greatly.
- Corrected bug when importing a microgame.
- Corrected wrong color choice when importing an image.
- Added option to edit microgame length.
- Added Back button to the .sav tool screen to return to editing a microgame.

0.1 April 6 2010
- Initial test release for bug hunting.




To use, you will need access to your save file in RAW .sav format. Microgames are exported as a .mio file. You can currently edit some simple things:

Name
Command
Description
Brand (Company)
Creator
Serial (Four text letters and two numbers)
Preview Image (Click it to export/import an image. Imported images must be 96 x 64 .png files. Transparency will not work yet!)
Cart Shape (The gold cart is Nintendo's special cart. Please only use this for your own personal games. Releasing all your games as gold carts will annoy everyone.)
Cart Color
Logo Design
Logo Color
Length

There are also some included save tools.
Save tool screen buttons:

Open .sav - Select a DIY save file.
Export... - Export the selected microgame to a .mio file.
Import - Replace the selected slot with a .mio file.
Delete - Delete the selected microgame.
Save Changes - This will finalize any changes you have made (changes are shown in a list box).
Clear Changes - Removes a changes you have made.
Back - Return to the .mio editing screen.

(The Export button works without clicking Save Changes)



Credits:
Controle Extension Package for GM 8.0 by Hxs2007
Clean Memory DLL by Halo Shg